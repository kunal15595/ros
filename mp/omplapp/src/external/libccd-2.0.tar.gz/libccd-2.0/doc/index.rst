.. libccd documentation master file, created by
   sphinx-quickstart2 on Thu May 23 13:49:12 2013.

libccd's documentation
=======================

See homepage: http://libccd.danfis.cz

Contents:

.. toctree::
   :maxdepth: 2

   compile-and-install.rst
   examples.rst
   reference.rst


.. Indices and tables
.. ==================

.. * :ref:`genindex`
.. * :ref:`modindex`
.. * :ref:`search`

